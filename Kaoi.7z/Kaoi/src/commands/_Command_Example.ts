import MessageHandler from '../Handlers/MessageHandler'
import BaseCommand from '../lib/BaseCommand'
import WAClient from '../lib/WAClient'
import { IParsedArgs, ISimplifiedMessage } from '../typings'

export default class Command extends BaseCommand {
    constructor(client: WAClient, handler: MessageHandler) {
        super(client, handler, {
            command: 'command_goes_here',
            description: 'command description',
            category: 'category',
            usage: `${client.config.prefix}command`
        })
    }

    //eslint-disable-next-line
    run = async (M: ISimplifiedMessage, args: IParsedArgs): Promise<void> => {}
}
// send a list message!
        const rows = [
            { title: 'Row 1', description: "Hello it's description 1", rowId: 'rowid1' },
            { title: 'Row 2', description: "Hello it's description 2", rowId: 'rowid2' }
        ]

        const sections = [{ title: 'Section 1', rows: rows }]

        await this.client.sendMessage(M.from, {
            sections,
            title: '*𓁩NAB🜲bot〠⃟⛐*',
            description: '',
            buttonText: 'Action List',
            footerText: '© *𓁩NAB🜲bot〠⃟⛐* 2021',
            listType: 1
        } as WAListMessage,
        MessageType.listMessage,
        {
            contextInfo: {
                mentionedJid: [M.sender.jid]
            }
        })
